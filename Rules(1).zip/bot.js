
                let Discord;
                let Database;
                if(typeof window !== "undefined"){
                    Discord = DiscordJS;
                    Database = EasyDatabase;
                } else {
                    Discord = require("discord.js");
                    Database = require("easy-json-database");
                }
                const delay = (ms) => new Promise((resolve) => setTimeout(() => resolve(), ms));
                const s4d = {
                    Discord,
                    client: null,
                    tokenInvalid: false,
                    reply: null,
                    joiningMember: null,
                    database: new Database("./db.json"),
                    checkMessageExists() {
                        if (!s4d.client) throw new Error('You cannot perform message operations without a Discord.js client')
                        if (!s4d.client.readyTimestamp) throw new Error('You cannot perform message operations while the bot is not connected to the Discord API')
                    }
                };
                s4d.client = new s4d.Discord.Client({
                    fetchAllMembers: true
                });
                s4d.client.on('raw', async (packet) => {
                    if(['MESSAGE_REACTION_ADD', 'MESSAGE_REACTION_REMOVE'].includes(packet.t)){
                        const guild = s4d.client.guilds.cache.get(packet.d.guild_id);
                        if(!guild) return;
                        const member = guild.members.cache.get(packet.d.user_id) || guild.members.fetch(d.user_id).catch(() => {});
                        if(!member) return;
                        const channel = s4d.client.channels.cache.get(packet.d.channel_id);
                        if(!channel) return;
                        const message = channel.messages.cache.get(packet.d.message_id) || await channel.messages.fetch(packet.d.message_id).catch(() => {});
                        if(!message) return;
                        s4d.client.emit(packet.t, guild, channel, message, member, packet.d.emoji.name);
                    }
                });
                s4d.client.login('ODM3MjI1MjM5MjAwMDA2MTU0.YIpcww.XTZ8xuY9gFodj82b1c51CLfPSOc').catch((e) => { s4d.tokenInvalid = true; s4d.tokenError = e; });

s4d.client.on('message', async (s4dmessage) => {
  if ((s4dmessage.content) == 'Rules') {
    s4dmessage.channel.send(String((['Hello ',s4dmessage.member,', Rules are listed below','\n','1. DO NOT BULLY PEOPLE ','\n','2. HACKING CAN EVEN BAN YOU ','\n',' 3. YOU MUST AGREE TO DISCORD GUIDELINES '].join(''))));
    (s4dmessage.channel).send(String('Write \'Agree\' to accept the rules. AHQ Bot, AHQ Discord secure'));
    (s4dmessage.channel).awaitMessages((m) => m.author.id === (s4dmessage.member).id, { time: (1*60*1000), max: 1 }).then(async (collected) => { s4d.reply = collected.first().content;
       if ((s4d.reply) == 'Agree') {
        s4dmessage.channel.send(String((['You are verified',s4dmessage.member,'! All the best'].join(''))));
        (s4dmessage.member).roles.add((s4dmessage.member).guild.roles.cache.find((role) => role.id === '@rulesaccepted' || role.name === '@rulesaccepted' || '@'+role.name === '@rulesaccepted'));
      }
      if ((s4d.reply) == 'agree') {
        s4dmessage.channel.send(String((['You are verified',s4dmessage.member,'! All the best'].join(''))));
        (s4dmessage.member).roles.add((s4dmessage.member).guild.roles.cache.find((role) => role.id === '@rulesaccepted' || role.name === '@rulesaccepted' || '@'+role.name === '@rulesaccepted'));
      }

     s4d.reply = null; }).catch(async (e) => { console.error(e);   s4dmessage.channel.send(String((['Session expired',s4dmessage.member,'! Try again'].join(''))));
     });}
  if ((s4dmessage.content) == 'rules') {
    s4dmessage.channel.send(String((['Hello ',s4dmessage.member,', Rules are listed below','\n','1. DO NOT BULLY PEOPLE ','\n','2. HACKING CAN EVEN BAN YOU ','\n',' 3. YOU MUST AGREE TO DISCORD GUIDELINES '].join(''))));
    (s4dmessage.channel).send(String('Write \'agree\' to accept the rules. AHQ Bot, AHQ Discord secure'));
    (s4dmessage.channel).awaitMessages((m) => m.author.id === (s4dmessage.member).id, { time: (1*60*1000), max: 1 }).then(async (collected) => { s4d.reply = collected.first().content;
       if ((s4d.reply) == 'Agree') {
        s4dmessage.channel.send(String((['You are verified',s4dmessage.member,'! All the best'].join(''))));
        (s4dmessage.member).roles.add((s4dmessage.member).guild.roles.cache.find((role) => role.id === '@rulesaccepted' || role.name === '@rulesaccepted' || '@'+role.name === '@rulesaccepted'));
      }
      if ((s4d.reply) == 'agree') {
        s4dmessage.channel.send(String((['You are verified',s4dmessage.member,'! All the best'].join(''))));
        (s4dmessage.member).roles.add((s4dmessage.member).guild.roles.cache.find((role) => role.id === '@rulesaccepted' || role.name === '@rulesaccepted' || '@'+role.name === '@rulesaccepted'));
      }

     s4d.reply = null; }).catch(async (e) => { console.error(e);   s4dmessage.channel.send(String((['Session expired',s4dmessage.member,'! Try again'].join(''))));
     });}
  if ((s4dmessage.content) == 'Start bot') {
    s4dmessage.channel.send(String((['Hello ',', Rules are listed below','\n','1. DO NOT BULLY PEOPLE ','\n','2. HACKING CAN EVEN BAN YOU ','\n',' 3. YOU MUST AGREE TO DISCORD GUIDELINES ','\n','Write \'Rules\' to start the session'].join(''))));
  }

});

                s4d;
            